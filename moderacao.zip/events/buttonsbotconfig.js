const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
} = require('discord.js');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    if (!interaction.isButton() && !interaction.isModalSubmit()) return;

    try {
      if (interaction.customId === 'change_name') {
        const modal = new ModalBuilder()
          .setCustomId('modal_change_name')
          .setTitle('Alterar Nome do Bot');

        const input = new TextInputBuilder()
          .setCustomId('bot_name_input')
          .setLabel('Digite o novo apelido do bot (2-32 caracteres)')
          .setStyle(TextInputStyle.Short)
          .setRequired(true);

        const row = new ActionRowBuilder().addComponents(input);
        modal.addComponents(row);

        await interaction.showModal(modal);
      } else if (interaction.customId === 'modal_change_name') {
        const botName = interaction.fields.getTextInputValue('bot_name_input');
        if (botName.length < 2 || botName.length > 32) {
          await interaction.reply({ content: '❌ O nome deve ter entre 2 e 32 caracteres.', ephemeral: true });
          return;
        }
        const botMember = interaction.guild?.members.cache.get(client.user.id);
        if (botMember) {
          await botMember.setNickname(botName);
          await interaction.reply({ content: `✅ Nome alterado para: **${botName}**.`, ephemeral: true });
        } else {
          await interaction.reply({ content: '❌ Não foi possível alterar o nome.', ephemeral: true });
        }
      } else if (interaction.customId === 'change_avatar') {
        const modal = new ModalBuilder()
          .setCustomId('modal_change_avatar')
          .setTitle('Alterar Avatar do Bot');

        const input = new TextInputBuilder()
          .setCustomId('bot_avatar_input')
          .setLabel('Link da nova foto (deve começar com https://)')
          .setStyle(TextInputStyle.Short)
          .setRequired(true);

        const row = new ActionRowBuilder().addComponents(input);
        modal.addComponents(row);

        await interaction.showModal(modal);
      } else if (interaction.customId === 'modal_change_avatar') {
        const avatarURL = interaction.fields.getTextInputValue('bot_avatar_input');
        if (!avatarURL.startsWith('https://')) {
          await interaction.reply({ content: '❌ O link deve começar com https://.', ephemeral: true });
          return;
        }
        try {
          await client.user.setAvatar(avatarURL);
          await interaction.reply({ content: '✅ Avatar alterado com sucesso!', ephemeral: true });
        } catch (error) {
          await interaction.reply({ content: '❌ Ocorreu um erro ao alterar o avatar. Certifique-se de que o link é válido.', ephemeral: true });
        }
      }
    } catch (error) {
      console.error('Erro durante a interação:', error);
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Ocorreu um erro ao processar a interação.', ephemeral: true });
      }
    }
  },
};