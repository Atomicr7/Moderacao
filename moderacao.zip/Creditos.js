Desenvolvido Por: Nery #Programador
Usuário do Discord: @nerydev

bot oficial do servidor de vazamentos
Vanguard: https://discord.gg/6WD79uahww

por favor deixe este crédito é muito importante para mim
se quiser uma versão sem créditos originais
faça você mesmo ;)